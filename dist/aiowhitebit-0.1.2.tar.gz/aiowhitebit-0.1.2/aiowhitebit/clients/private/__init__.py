"""Private API clients."""

from aiowhitebit.clients.private.v4 import PrivateV4Client
