# Changelog

## [0.1.1] - 2024-03-14

### Added
- Initial release
- Support for WhiteBit Public API v1, v2, and v4
- Support for Private API v4
- WebSocket client implementation
- Webhook support
